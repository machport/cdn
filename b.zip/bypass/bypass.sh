#!/bin/bash

rm -rf ~/.ssh/known_hosts

python ./tcprelay.py 44:2222 &
sleep 1
./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 mount -o rw,union,update /

./sshpass -p alpine scp -rP 2222 -o StrictHostKeyChecking=no ./bypass root@localhost:/usr/libexec/bypass


./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 mv /usr/libexec/mobileactivationd /usr/libexec/mobileactivationdbak

./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 mv /usr/libexec/bypass /usr/libexec/mobileactivationd

./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 chmod 755 /usr/libexec/mobileactivationd

./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 launchctl unload /System/Library/LaunchDaemons/com.apple.mobileactivationd.plist

./sshpass -p "alpine" ssh -o StrictHostKeyChecking=no root@localhost -p 2222 launchctl load /System/Library/LaunchDaemons/com.apple.mobileactivationd.plist
killall Python